import { Component } from '@angular/core';

@Component({
  selector: 'Home-component',
  templateUrl: './Home.component.html',
  styleUrls: ['./Home.component.scss']
})
export class NewComponentComponent {

}
