import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule  }   from '@angular/forms';
import { SignInComponent } from './component/sign-in/sign-in.component';
import { LoginComponent } from './component/login/login.component';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [SignInComponent,LoginComponent],
  imports: [
    CommonModule,
    SharedModule
  ]
})
export class AuthModule { }
