import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SignInComponent } from './component/sign-in/sign-in.component';
import { LoginComponent } from './component/login/login.component';
import { NewComponentComponent } from '../shell/Home/Home.component';
const routes:Routes=[
  {path:'',component:NewComponentComponent},
  {path:'LoginIn',component:LoginComponent},
  {path:'Signup',component:SignInComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
