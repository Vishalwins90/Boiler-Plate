import { Component,OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss']
})
export class SignInComponent implements OnInit {
  SignIn:any
 FormGroup:any
  hide = false
  constructor(){

  }

// SignIn= new FormGroup(
//  {
//   name : new FormControl('',[Validators.pattern(/\s/)]),
//    LastName: new FormControl('',[Validators.pattern(/\s/)]),
//    email : new FormControl('',[Validators.required,Validators.email]),
//    password: new FormControl('', Validators.pattern('^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{8,}$')),
//  }

// );

Login(){
}
  ngOnInit() : void{
     this.SignIn  = new FormGroup(
     {
      name : new FormControl('',[Validators.pattern(/\s/)]),
        LastName: new FormControl('',[Validators.pattern(/\s/)]),
          email : new FormControl('',[Validators.required,Validators.email]),
         password: new FormControl('', Validators.pattern('^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{8,}$'))
        }
      
    
     );
    
     }
    

    }

